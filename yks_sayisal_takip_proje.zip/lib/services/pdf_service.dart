import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/study_models.dart';

class PdfService {
  static Future<pw.Font> _loadRegularFont() async {
    try {
      final data = await rootBundle.load('assets/fonts/Roboto-Regular.ttf');
      return pw.Font.ttf(data);
    } catch (_) {
      try {
        return await PdfGoogleFonts.robotoRegular();
      } catch (_) {
        return pw.Font.helvetica();
      }
    }
  }

  static Future<pw.Font> _loadBoldFont() async {
    try {
      final data = await rootBundle.load('assets/fonts/Roboto-Bold.ttf');
      return pw.Font.ttf(data);
    } catch (_) {
      try {
        return await PdfGoogleFonts.robotoBold();
      } catch (_) {
        return pw.Font.helveticaBold();
      }
    }
  }

  static Future<void> generateAndPreviewWeeklyReport({
    required DateTime weekStart,
    required DateTime weekEnd,
    required List<StudySession> weeklySessions,
    required List<RedListItem> redList,
    required WeeklyGoal goal,
    required double goalProgressPercent,
  }) async {
    final regularFont = await _loadRegularFont();
    final boldFont = await _loadBoldFont();

    final pdf = pw.Document(
      theme: pw.ThemeData.withFont(
        base: regularFont,
        bold: boldFont,
      ),
    );

    final dateFormat = DateFormat('dd.MM.yyyy');
    final totalMinutes =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.durationMinutes);
    final totalQuestions =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.totalQuestions);
    final totalNet =
        weeklySessions.fold<double>(0.0, (sum, s) => sum + s.net);
    final avgNet =
        weeklySessions.isEmpty ? 0.0 : totalNet / weeklySessions.length;

    final branchTrials = weeklySessions
        .where((s) => s.sessionType == SessionType.branchTrial)
        .toList();

    final Map<int, List<StudySession>> sessionsByWeekday = {
      for (int i = 1; i <= 7; i++) i: []
    };
    for (final s in weeklySessions) {
      sessionsByWeekday[s.date.weekday]?.add(s);
    }

    final Map<String, int> durationBySubject = {};
    final Map<String, int> questionsBySubject = {};
    for (final s in weeklySessions) {
      durationBySubject[s.subject] =
          (durationBySubject[s.subject] ?? 0) + s.durationMinutes;
      questionsBySubject[s.subject] =
          (questionsBySubject[s.subject] ?? 0) + s.totalQuestions;
    }

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(24),
        build: (context) => [
          _buildTopBanner(
            dateRange:
                '${dateFormat.format(weekStart)} - ${dateFormat.format(weekEnd)}',
            totalMinutes: totalMinutes,
            totalQuestions: totalQuestions,
            avgNet: avgNet,
            goalProgressPercent: goalProgressPercent,
            goal: goal,
          ),
          pw.SizedBox(height: 14),
          pw.Text(
            'HAFTALIK ÇALIŞMA ÇİZELGESİ (PAZARTESİ - PAZAR)',
            style: pw.TextStyle(
              fontSize: 11,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.blueGrey900,
            ),
          ),
          pw.SizedBox(height: 6),
          _buildWeeklyGridTable(sessionsByWeekday, weekStart),
          pw.SizedBox(height: 14),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(
                flex: 4,
                child: _buildTrialsPanel(branchTrials),
              ),
              pw.SizedBox(width: 12),
              pw.Expanded(
                flex: 4,
                child: _buildRedListPanel(redList),
              ),
              pw.SizedBox(width: 12),
              pw.Expanded(
                flex: 4,
                child: _buildSubjectDistributionPanel(
                  durationBySubject,
                  questionsBySubject,
                  totalMinutes,
                ),
              ),
            ],
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
      name: 'YKS_Sayisal_Haftalik_Rapor_${dateFormat.format(weekStart)}.pdf',
    );
  }

  static pw.Widget _buildTopBanner({
    required String dateRange,
    required int totalMinutes,
    required int totalQuestions,
    required double avgNet,
    required double goalProgressPercent,
    required WeeklyGoal goal,
  }) {
    final hours = totalMinutes ~/ 60;
    final mins = totalMinutes % 60;
    final goalText = goal.goalType == GoalType.hours
        ? '${goal.targetValue} Saat'
        : '${goal.targetValue} Soru';

    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: pw.BoxDecoration(
        color: PdfColors.indigo900,
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'YKS SAYISAL HAFTALIK ANALİZ VE TAKİP RAPORU',
                style: pw.TextStyle(
                  color: PdfColors.white,
                  fontSize: 13,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 2),
              pw.Text(
                'Dönem: $dateRange',
                style: const pw.TextStyle(color: PdfColors.grey300, fontSize: 9),
              ),
            ],
          ),
          _bannerStatBox('Toplam Süre', '${hours}s ${mins}dk'),
          _bannerStatBox('Çözülen Soru', '$totalQuestions Soru'),
          _bannerStatBox('Ortalama Net', avgNet.toStringAsFixed(2)),
          _bannerStatBox(
            'Haftalık Hedef ($goalText)',
            '%${(goalProgressPercent * 100).toStringAsFixed(1)}',
          ),
        ],
      ),
    );
  }

  static pw.Widget _bannerStatBox(String label, String value) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: pw.BoxDecoration(
        color: PdfColors.indigo700,
        borderRadius: pw.BorderRadius.circular(4),
      ),
      child: pw.Column(
        children: [
          pw.Text(label,
              style: const pw.TextStyle(color: PdfColors.grey200, fontSize: 8)),
          pw.SizedBox(height: 2),
          pw.Text(
            value,
            style: pw.TextStyle(
              color: PdfColors.white,
              fontSize: 11,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildWeeklyGridTable(
    Map<int, List<StudySession>> sessionsByWeekday,
    DateTime weekStart,
  ) {
    const dayNames = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.6),
      columnWidths: {
        for (int i = 0; i < 7; i++) i: const pw.FlexColumnWidth(1),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.blueGrey100),
          children: List.generate(7, (index) {
            final dayDate = weekStart.add(Duration(days: index));
            final daySessions = sessionsByWeekday[index + 1] ?? [];
            final dayMins =
                daySessions.fold<int>(0, (sum, s) => sum + s.durationMinutes);
            final dayQs =
                daySessions.fold<int>(0, (sum, s) => sum + s.totalQuestions);

            return pw.Padding(
              padding: const pw.EdgeInsets.all(5),
              child: pw.Column(
                children: [
                  pw.Text(
                    '${dayNames[index]} (${DateFormat('dd.MM').format(dayDate)})',
                    style: pw.TextStyle(
                        fontSize: 8.5, fontWeight: pw.FontWeight.bold),
                  ),
                  pw.Text(
                    '${dayMins}dk | ${dayQs}S',
                    style: const pw.TextStyle(
                        fontSize: 7.5, color: PdfColors.blueGrey800),
                  ),
                ],
              ),
            );
          }),
        ),
        pw.TableRow(
          children: List.generate(7, (index) {
            final daySessions = sessionsByWeekday[index + 1] ?? [];
            if (daySessions.isEmpty) {
              return pw.Padding(
                padding: const pw.EdgeInsets.all(6),
                child: pw.Text(
                  'Kayıt Yok',
                  style: const pw.TextStyle(
                      fontSize: 7.5, color: PdfColors.grey500),
                ),
              );
            }

            return pw.Padding(
              padding: const pw.EdgeInsets.all(4),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: daySessions.map((s) {
                  final timeLabel = s.recordingMode == RecordingMode.timeRange &&
                          s.startTime != null &&
                          s.endTime != null
                      ? '${s.startTime}-${s.endTime}'
                      : '${s.durationMinutes}dk';

                  return pw.Container(
                    margin: const pw.EdgeInsets.only(bottom: 4),
                    padding: const pw.EdgeInsets.all(3),
                    decoration: pw.BoxDecoration(
                      color: s.sessionType == SessionType.branchTrial
                          ? PdfColors.amber50
                          : PdfColors.grey100,
                      border: pw.Border.all(color: PdfColors.grey300, width: 0.4),
                    ),
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          s.subject,
                          style: pw.TextStyle(
                              fontSize: 7.5, fontWeight: pw.FontWeight.bold),
                        ),
                        pw.Text(
                          s.topic,
                          style: const pw.TextStyle(fontSize: 7),
                          maxLines: 1,
                        ),
                        pw.Text(
                          '$timeLabel | ${s.totalQuestions}S | ${s.net.toStringAsFixed(1)}N',
                          style: const pw.TextStyle(
                              fontSize: 6.8, color: PdfColors.indigo800),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            );
          }),
        ),
      ],
    );
  }

  static pw.Widget _buildTrialsPanel(List<StudySession> trials) {
    final maxNet = trials.isEmpty
        ? 40.0
        : trials
            .map((e) => e.net)
            .reduce((a, b) => a > b ? a : b)
            .clamp(10.0, 120.0);

    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey400, width: 0.6),
        borderRadius: pw.BorderRadius.circular(4),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'BRANŞ DENEMELERİ VE NET EĞRİSİ',
            style: pw.TextStyle(
              fontSize: 9.5,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.indigo900,
            ),
          ),
          pw.Divider(color: PdfColors.grey400, height: 8),
          if (trials.isEmpty)
            pw.Text('Bu hafta branş denemesi kaydedilmedi.',
                style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600))
          else
            ...trials.take(7).map((t) {
              final ratio = (t.net / maxNet).clamp(0.05, 1.0);
              return pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 2),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        pw.Expanded(
                          child: pw.Text(
                            '${DateFormat('dd.MM').format(t.date)} - ${t.topic}',
                            style: const pw.TextStyle(fontSize: 7.5),
                            maxLines: 1,
                          ),
                        ),
                        pw.Text(
                          '${t.net.toStringAsFixed(2)} Net (${t.durationMinutes}dk)',
                          style: pw.TextStyle(
                              fontSize: 7.5, fontWeight: pw.FontWeight.bold),
                        ),
                      ],
                    ),
                    pw.SizedBox(height: 2),
                    pw.Container(
                      height: 5,
                      width: 180 * ratio,
                      decoration: pw.BoxDecoration(
                        color: PdfColors.indigo600,
                        borderRadius: pw.BorderRadius.circular(2),
                      ),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  static pw.Widget _buildRedListPanel(List<RedListItem> redList) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        color: PdfColors.red50,
        border: pw.Border.all(color: PdfColors.red300, width: 0.8),
        borderRadius: pw.BorderRadius.circular(4),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'KIRMIZI LİSTE (TEKRAR EDİLECEKLER)',
            style: pw.TextStyle(
              fontSize: 9.5,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.red900,
            ),
          ),
          pw.Divider(color: PdfColors.red200, height: 8),
          if (redList.isEmpty)
            pw.Text(
              'Harika! Hata oranı %20 sınırını aşan konu bulunmuyor.',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.green900),
            )
          else
            ...redList.take(8).map((item) {
              final errPct = (item.wrongRatio * 100).toStringAsFixed(0);
              return pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 2),
                child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Expanded(
                      child: pw.Text(
                        '• ${item.subject}: ${item.topic}',
                        style: const pw.TextStyle(fontSize: 7.5),
                        maxLines: 1,
                      ),
                    ),
                    pw.Text(
                      item.isManual && item.totalQuestions == 0
                          ? 'Manuel'
                          : '%$errPct Yanlış (${item.totalWrong}/${item.totalQuestions})',
                      style: pw.TextStyle(
                        fontSize: 7.5,
                        fontWeight: pw.FontWeight.bold,
                        color: PdfColors.red800,
                      ),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  static pw.Widget _buildSubjectDistributionPanel(
    Map<String, int> durationBySubject,
    Map<String, int> questionsBySubject,
    int totalMinutes,
  ) {
    final entries = durationBySubject.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey400, width: 0.6),
        borderRadius: pw.BorderRadius.circular(4),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'SAYISAL DERS DAĞILIM ÇİZELGESİ',
            style: pw.TextStyle(
              fontSize: 9.5,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.blueGrey900,
            ),
          ),
          pw.Divider(color: PdfColors.grey400, height: 8),
          if (entries.isEmpty)
            pw.Text('Ders verisi yok.',
                style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600))
          else
            ...entries.map((e) {
              final share =
                  totalMinutes > 0 ? (e.value / totalMinutes) * 100 : 0.0;
              final qCount = questionsBySubject[e.key] ?? 0;
              return pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 2),
                child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Expanded(
                      child: pw.Text(e.key,
                          style: const pw.TextStyle(fontSize: 7.5)),
                    ),
                    pw.Text(
                      '${e.value}dk (%${share.toStringAsFixed(1)}) | ${qCount}S',
                      style: pw.TextStyle(
                          fontSize: 7.5, fontWeight: pw.FontWeight.bold),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }
}
