import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../data/curriculum_data.dart';
import '../models/study_models.dart';
import '../providers/app_providers.dart';
import 'end_of_day_wizard.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weeklySessions = ref.watch(currentWeekSessionsProvider);
    final goal = ref.watch(weeklyGoalProvider);
    final progress = ref.watch(weeklyProgressProvider);
    final redList = ref.watch(redListProvider);

    final totalMinutes =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.durationMinutes);
    final totalQuestions =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.totalQuestions);

    return Scaffold(
      appBar: AppBar(
        title: const Text('YKS Sayısal Koç & Analiz'),
        actions: [
          TextButton.icon(
            onPressed: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              useSafeArea: true,
              builder: (_) => const EndOfDayWizardModal(),
            ),
            icon: const Icon(Icons.bolt, color: Colors.amber),
            label: const Text(
              'Gün Sonu Sihirbazı',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildWeeklyGoalCard(goal, progress, totalMinutes, totalQuestions),
          const SizedBox(height: 16),
          _buildRedListCard(context, ref, redList),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Bu Haftanın Kayıtları',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
              Text(
                '${weeklySessions.length} Oturum',
                style: const TextStyle(color: Colors.grey),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (weeklySessions.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: Text(
                    'Bu hafta henüz çalışma kaydı girilmedi.\nSağ alttaki + butonundan veya Gün Sonu Sihirbazından ekleyebilirsiniz.',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            )
          else
            ...weeklySessions.map((s) => _buildSessionTile(ref, s)),
          const SizedBox(height: 80),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          useSafeArea: true,
          builder: (_) => const AddStudySessionModal(),
        ),
        icon: const Icon(Icons.add),
        label: const Text('Çalışma / Deneme Ekle'),
      ),
    );
  }

  Widget _buildWeeklyGoalCard(
    WeeklyGoal goal,
    double progress,
    int totalMinutes,
    int totalQuestions,
  ) {
    final clamped = progress.clamp(0.0, 1.0);
    final pctText = (progress * 100).toStringAsFixed(1);
    final hours = (totalMinutes / 60).toStringAsFixed(1);

    final statusSubtitle = goal.goalType == GoalType.hours
        ? '$hours / ${goal.targetValue} Saat Tamamlandı'
        : '$totalQuestions / ${goal.targetValue} Soru Çözüldü';

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Haftalık Hedef İlerlemesi',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Chip(
                  label: Text('%$pctText',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  backgroundColor: Colors.indigo.withOpacity(0.15),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: clamped,
                minHeight: 12,
                backgroundColor: Colors.grey.shade300,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(statusSubtitle,
                    style: const TextStyle(fontWeight: FontWeight.w500)),
                Text('Toplam: ${totalMinutes}dk • $totalQuestions Soru',
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRedListCard(
      BuildContext context, WidgetRef ref, List<RedListItem> redList) {
    return Card(
      color: redList.isEmpty ? Colors.green.shade50 : Colors.red.shade50,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: redList.isEmpty ? Colors.green.shade300 : Colors.red.shade300,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  redList.isEmpty ? Icons.check_circle : Icons.warning_amber,
                  color: redList.isEmpty ? Colors.green.shade800 : Colors.red.shade800,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    redList.isEmpty
                        ? 'Kırmızı Liste Temiz'
                        : 'Kırmızı Liste (${redList.length} Hatalı Konu)',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: redList.isEmpty
                          ? Colors.green.shade900
                          : Colors.red.shade900,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            if (redList.isEmpty)
              const Text(
                'Yanlış oranı %20 sınırını aşan veya tekrar bekleyen konu yok.',
                style: TextStyle(fontSize: 13),
              )
            else
              ...redList.map((item) {
                final pct = (item.wrongRatio * 100).toStringAsFixed(0);
                return ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    '${item.subject} - ${item.topic}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    item.isManual && item.totalQuestions == 0
                        ? 'Manuel eklendi (Tekrar Bekliyor)'
                        : 'Yanlış Oranı: %$pct (${item.totalWrong} Y / ${item.totalQuestions} Toplam Soru)',
                    style: TextStyle(color: Colors.red.shade900),
                  ),
                  trailing: TextButton.icon(
                    onPressed: () {
                      ref
                          .read(checklistProvider.notifier)
                          .markRedListTopicReviewed(item.keyId);
                    },
                    icon: const Icon(Icons.done_all, size: 18),
                    label: const Text('Tekrar Edildi'),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionTile(WidgetRef ref, StudySession s) {
    final isTrial = s.sessionType == SessionType.branchTrial;
    final timeStr = s.recordingMode == RecordingMode.timeRange &&
            s.startTime != null &&
            s.endTime != null
        ? '${s.startTime} - ${s.endTime} (${s.durationMinutes} dk)'
        : '${s.durationMinutes} dk';

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor:
              isTrial ? Colors.deepOrange.shade100 : Colors.indigo.shade100,
          child: Icon(
            isTrial ? Icons.assignment_turned_in : Icons.menu_book,
            color: isTrial ? Colors.deepOrange.shade800 : Colors.indigo.shade800,
          ),
        ),
        title: Text(
          '${s.subject} • ${s.topic}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${DateFormat('dd.MM.yyyy').format(s.date)} | $timeStr\n'
          'D: ${s.correctCount}  Y: ${s.wrongCount}  B: ${s.emptyCount}  →  Net: ${s.net.toStringAsFixed(2)}',
        ),
        isThreeLine: true,
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
          onPressed: () =>
              ref.read(studySessionsProvider.notifier).deleteSession(s.id),
        ),
      ),
    );
  }
}

class AddStudySessionModal extends ConsumerStatefulWidget {
  const AddStudySessionModal({super.key});

  @override
  ConsumerState<AddStudySessionModal> createState() =>
      _AddStudySessionModalState();
}

class _AddStudySessionModalState extends ConsumerState<AddStudySessionModal> {
  RecordingMode _recordingMode = RecordingMode.timeRange;
  SessionType _sessionType = SessionType.topicStudy;

  TimeOfDay _startTime = const TimeOfDay(hour: 13, minute: 30);
  TimeOfDay _endTime = const TimeOfDay(hour: 15, minute: 0);

  final TextEditingController _durationCtrl = TextEditingController(text: '60');
  final TextEditingController _correctCtrl = TextEditingController(text: '20');
  final TextEditingController _wrongCtrl = TextEditingController(text: '2');
  final TextEditingController _emptyCtrl = TextEditingController(text: '0');

  late String _selectedSubject;
  late String _selectedTopic;
  String _selectedTrialBranch = CurriculumData.branchTrialTypes.first;

  Timer? _stopwatchTimer;
  int _elapsedSeconds = 0;
  bool _isRunning = false;

  @override
  void initState() {
    super.initState();
    _selectedSubject = CurriculumData.allSubjects.first;
    _selectedTopic = CurriculumData.sayisalCurriculum[_selectedSubject]!.first;
  }

  @override
  void dispose() {
    _stopwatchTimer?.cancel();
    _durationCtrl.dispose();
    _correctCtrl.dispose();
    _wrongCtrl.dispose();
    _emptyCtrl.dispose();
    super.dispose();
  }

  int _calculateTimeRangeMinutes() {
    final startMins = _startTime.hour * 60 + _startTime.minute;
    final endMins = _endTime.hour * 60 + _endTime.minute;
    final diff = endMins - startMins;
    return diff > 0 ? diff : diff + 1440;
  }

  void _toggleStopwatch() {
    if (_isRunning) {
      _stopwatchTimer?.cancel();
      setState(() {
        _isRunning = false;
        final mins = (_elapsedSeconds / 60).ceil();
        _durationCtrl.text = (mins > 0 ? mins : 1).toString();
      });
    } else {
      setState(() => _isRunning = true);
      _stopwatchTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        setState(() {
          _elapsedSeconds++;
          _durationCtrl.text = ((_elapsedSeconds / 60).ceil()).toString();
        });
      });
    }
  }

  String _formatTimeOfDay(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  void _save() {
    final duration = _recordingMode == RecordingMode.timeRange
        ? _calculateTimeRangeMinutes()
        : (int.tryParse(_durationCtrl.text) ?? 40);

    final correct = int.tryParse(_correctCtrl.text) ?? 0;
    final wrong = int.tryParse(_wrongCtrl.text) ?? 0;
    final empty = int.tryParse(_emptyCtrl.text) ?? 0;

    final session = StudySession(
      id: const Uuid().v4(),
      date: DateTime.now(),
      recordingMode: _recordingMode,
      startTime: _recordingMode == RecordingMode.timeRange
          ? _formatTimeOfDay(_startTime)
          : null,
      endTime: _recordingMode == RecordingMode.timeRange
          ? _formatTimeOfDay(_endTime)
          : null,
      durationMinutes: duration,
      sessionType: _sessionType,
      subject: _sessionType == SessionType.topicStudy
          ? _selectedSubject
          : 'Branş Denemesi',
      topic: _sessionType == SessionType.topicStudy
          ? _selectedTopic
          : _selectedTrialBranch,
      correctCount: correct,
      wrongCount: wrong,
      emptyCount: empty,
    );

    ref.read(studySessionsProvider.notifier).addSession(session);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final topics = CurriculumData.sayisalCurriculum[_selectedSubject] ?? [];
    final correct = int.tryParse(_correctCtrl.text) ?? 0;
    final wrong = int.tryParse(_wrongCtrl.text) ?? 0;
    final net = correct - (wrong / 4.0);

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Yeni Çalışma Oturumu Kaydet',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            SegmentedButton<SessionType>(
              segments: const [
                ButtonSegment(
                  value: SessionType.topicStudy,
                  label: Text('Soru Bankası / Konu'),
                  icon: Icon(Icons.menu_book),
                ),
                ButtonSegment(
                  value: SessionType.branchTrial,
                  label: Text('Branş / Alan Denemesi'),
                  icon: Icon(Icons.timer),
                ),
              ],
              selected: {_sessionType},
              onSelectionChanged: (val) =>
                  setState(() => _sessionType = val.first),
            ),
            const SizedBox(height: 12),
            SegmentedButton<RecordingMode>(
              segments: const [
                ButtonSegment(
                  value: RecordingMode.timeRange,
                  label: Text('Saat Modu'),
                  icon: Icon(Icons.access_time),
                ),
                ButtonSegment(
                  value: RecordingMode.duration,
                  label: Text('Süre / Sayaç Modu'),
                  icon: Icon(Icons.av_timer),
                ),
              ],
              selected: {_recordingMode},
              onSelectionChanged: (val) =>
                  setState(() => _recordingMode = val.first),
            ),
            const SizedBox(height: 12),
            if (_recordingMode == RecordingMode.timeRange)
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: _startTime,
                        );
                        if (picked != null) setState(() => _startTime = picked);
                      },
                      icon: const Icon(Icons.play_arrow),
                      label: Text('Başlangıç: ${_formatTimeOfDay(_startTime)}'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: _endTime,
                        );
                        if (picked != null) setState(() => _endTime = picked);
                      },
                      icon: const Icon(Icons.stop),
                      label: Text('Bitiş: ${_formatTimeOfDay(_endTime)}'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Chip(label: Text('${_calculateTimeRangeMinutes()} dk')),
                ],
              )
            else
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _durationCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Çalışma Süresi (Dakika)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  FilledButton.tonalIcon(
                    onPressed: _toggleStopwatch,
                    icon: Icon(_isRunning ? Icons.pause : Icons.play_arrow),
                    label: Text(
                      _isRunning
                          ? '${(_elapsedSeconds ~/ 60).toString().padLeft(2, '0')}:${(_elapsedSeconds % 60).toString().padLeft(2, '0')}'
                          : 'Sayaç Başlat',
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 12),
            if (_sessionType == SessionType.topicStudy) ...[
              DropdownButtonFormField<String>(
                value: _selectedSubject,
                decoration: const InputDecoration(
                  labelText: 'Ders Seçin',
                  border: OutlineInputBorder(),
                ),
                items: CurriculumData.allSubjects
                    .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                    .toList(),
                onChanged: (val) {
                  if (val != null) {
                    setState(() {
                      _selectedSubject = val;
                      _selectedTopic =
                          CurriculumData.sayisalCurriculum[val]!.first;
                    });
                  }
                },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _selectedTopic,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Konu Seçin',
                  border: OutlineInputBorder(),
                ),
                items: topics
                    .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                    .toList(),
                onChanged: (val) {
                  if (val != null) setState(() => _selectedTopic = val);
                },
              ),
            ] else
              DropdownButtonFormField<String>(
                value: _selectedTrialBranch,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Branş / Alan Denemesi Türü',
                  border: OutlineInputBorder(),
                ),
                items: CurriculumData.branchTrialTypes
                    .map((b) => DropdownMenuItem(value: b, child: Text(b)))
                    .toList(),
                onChanged: (val) {
                  if (val != null) setState(() => _selectedTrialBranch = val);
                },
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _correctCtrl,
                    keyboardType: TextInputType.number,
                    onChanged: (_) => setState(() {}),
                    decoration: const InputDecoration(
                      labelText: 'Doğru',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _wrongCtrl,
                    keyboardType: TextInputType.number,
                    onChanged: (_) => setState(() {}),
                    decoration: const InputDecoration(
                      labelText: 'Yanlış',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _emptyCtrl,
                    keyboardType: TextInputType.number,
                    onChanged: (_) => setState(() {}),
                    decoration: const InputDecoration(
                      labelText: 'Boş',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Hesaplanan Net: ${net.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo,
                  ),
                ),
                FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.save),
                  label: const Text('Kaydet'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
