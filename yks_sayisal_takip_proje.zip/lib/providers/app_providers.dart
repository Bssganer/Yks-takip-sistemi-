import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import '../data/curriculum_data.dart';
import '../models/study_models.dart';
import '../services/notification_service.dart';
import '../services/settings_service.dart';

final settingsServiceProvider = Provider<SettingsService>((ref) {
  throw UnimplementedError('main.dart içinde override edilmelidir');
});

final studySessionsBoxProvider = Provider<Box<StudySession>>((ref) {
  return Hive.box<StudySession>('study_sessions');
});

final checklistBoxProvider = Provider<Box<TopicChecklist>>((ref) {
  return Hive.box<TopicChecklist>('topic_checklists');
});

class StudySessionNotifier extends StateNotifier<List<StudySession>> {
  final Box<StudySession> _box;
  final Ref _ref;

  StudySessionNotifier(this._box, this._ref) : super(_box.values.toList()) {
    _sortSessions();
  }

  void _sortSessions() {
    state = [...state]..sort((a, b) => b.date.compareTo(a.date));
  }

  Future<void> addSession(StudySession session) async {
    await _box.put(session.id, session);
    if (session.sessionType == SessionType.topicStudy && session.isHighError) {
      await _ref
          .read(checklistProvider.notifier)
          .resetAutoRedListClearFlag(session.subject, session.topic);
    }
    state = _box.values.toList();
    _sortSessions();
  }

  Future<void> addMultipleSessions(List<StudySession> sessions) async {
    for (final s in sessions) {
      await _box.put(s.id, s);
      if (s.sessionType == SessionType.topicStudy && s.isHighError) {
        await _ref
            .read(checklistProvider.notifier)
            .resetAutoRedListClearFlag(s.subject, s.topic);
      }
    }
    state = _box.values.toList();
    _sortSessions();
  }

  Future<void> deleteSession(String id) async {
    await _box.delete(id);
    state = _box.values.toList();
    _sortSessions();
  }
}

final studySessionsProvider =
    StateNotifierProvider<StudySessionNotifier, List<StudySession>>((ref) {
  final box = ref.watch(studySessionsBoxProvider);
  return StudySessionNotifier(box, ref);
});

class ChecklistNotifier extends StateNotifier<Map<String, TopicChecklist>> {
  final Box<TopicChecklist> _box;

  ChecklistNotifier(this._box) : super({}) {
    _initCurriculum();
  }

  void _initCurriculum() {
    final Map<String, TopicChecklist> map = {};
    CurriculumData.sayisalCurriculum.forEach((subject, topics) {
      for (final topic in topics) {
        final key = '$subject|$topic';
        final existing = _box.get(key);
        if (existing != null) {
          map[key] = existing;
        } else {
          final created = TopicChecklist(
            keyId: key,
            subject: subject,
            topic: topic,
          );
          _box.put(key, created);
          map[key] = created;
        }
      }
    });
    state = map;
  }

  Future<void> toggleCompleted(String keyId) async {
    final current = state[keyId];
    if (current == null) return;
    final updated = current.copyWith(isCompleted: !current.isCompleted);
    await _box.put(keyId, updated);
    state = {...state, keyId: updated};
  }

  Future<void> toggleManualRedList(String keyId) async {
    final current = state[keyId];
    if (current == null) return;
    final updated = current.copyWith(
      isManualRedList: !current.isManualRedList,
      isClearedFromAutoRedList: false,
    );
    await _box.put(keyId, updated);
    state = {...state, keyId: updated};
  }

  Future<void> markRedListTopicReviewed(String keyId) async {
    final current = state[keyId];
    if (current == null) return;
    final updated = current.copyWith(
      isManualRedList: false,
      isClearedFromAutoRedList: true,
    );
    await _box.put(keyId, updated);
    state = {...state, keyId: updated};
  }

  Future<void> resetAutoRedListClearFlag(String subject, String topic) async {
    final keyId = '$subject|$topic';
    final current = state[keyId];
    if (current != null && current.isClearedFromAutoRedList) {
      final updated = current.copyWith(isClearedFromAutoRedList: false);
      await _box.put(keyId, updated);
      state = {...state, keyId: updated};
    }
  }
}

final checklistProvider =
    StateNotifierProvider<ChecklistNotifier, Map<String, TopicChecklist>>((ref) {
  final box = ref.watch(checklistBoxProvider);
  return ChecklistNotifier(box);
});

class WeeklyGoalNotifier extends StateNotifier<WeeklyGoal> {
  final SettingsService _service;

  WeeklyGoalNotifier(this._service) : super(_service.loadGoalSettings());

  Future<void> updateGoal(WeeklyGoal newGoal) async {
    await _service.saveGoalSettings(newGoal);
    await NotificationService().scheduleDailyEndOfDayReminder(
      newGoal.reminderHour,
      newGoal.reminderMinute,
    );
    state = newGoal;
  }
}

final weeklyGoalProvider =
    StateNotifierProvider<WeeklyGoalNotifier, WeeklyGoal>((ref) {
  final service = ref.watch(settingsServiceProvider);
  return WeeklyGoalNotifier(service);
});

final currentWeekSessionsProvider = Provider<List<StudySession>>((ref) {
  final allSessions = ref.watch(studySessionsProvider);
  final now = DateTime.now();
  final monday = DateTime(now.year, now.month, now.day)
      .subtract(Duration(days: now.weekday - 1));
  final nextMonday = monday.add(const Duration(days: 7));

  return allSessions.where((s) {
    return !s.date.isBefore(monday) && s.date.isBefore(nextMonday);
  }).toList();
});

final weeklyProgressProvider = Provider<double>((ref) {
  final weeklySessions = ref.watch(currentWeekSessionsProvider);
  final goal = ref.watch(weeklyGoalProvider);

  if (goal.targetValue <= 0) return 0.0;

  if (goal.goalType == GoalType.hours) {
    final totalMinutes =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.durationMinutes);
    final targetMinutes = goal.targetValue * 60;
    return totalMinutes / targetMinutes;
  } else {
    final totalQuestions =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.totalQuestions);
    return totalQuestions / goal.targetValue;
  }
});

final redListProvider = Provider<List<RedListItem>>((ref) {
  final sessions = ref.watch(studySessionsProvider);
  final checklistMap = ref.watch(checklistProvider);

  final Map<String, int> qMap = {};
  final Map<String, int> wMap = {};

  for (final s in sessions) {
    if (s.sessionType == SessionType.topicStudy) {
      final key = '${s.subject}|${s.topic}';
      qMap[key] = (qMap[key] ?? 0) + s.totalQuestions;
      wMap[key] = (wMap[key] ?? 0) + s.wrongCount;
    }
  }

  final List<RedListItem> redItems = [];

  checklistMap.forEach((key, item) {
    final totalQ = qMap[key] ?? 0;
    final totalW = wMap[key] ?? 0;
    final ratio = totalQ > 0 ? totalW / totalQ : 0.0;
    final autoTriggered =
        totalQ >= 5 && ratio > 0.20 && !item.isClearedFromAutoRedList;

    if (item.isManualRedList || autoTriggered) {
      redItems.add(
        RedListItem(
          subject: item.subject,
          topic: item.topic,
          totalQuestions: totalQ,
          totalWrong: totalW,
          wrongRatio: ratio,
          isManual: item.isManualRedList,
        ),
      );
    }
  });

  redItems.sort((a, b) => b.wrongRatio.compareTo(a.wrongRatio));
  return redItems;
});
