@echo off
chcp 65001 >nul
echo ====================================================
echo   YKS Sayisal Takip - GitHub Otomatik Yukleyici
echo ====================================================
echo.
set /p REPO_URL="GitHub Repo URL'nizi yapistirin (orn: https://github.com/kullanici/yks-takip.git): "

git init
git add .
git commit -m "feat: YKS Sayisal Takip tam proje ve GitHub Actions APK derleyici"
git branch -M main
git remote remove origin 2>nul
git remote add origin %REPO_URL%
git push -u origin main --force

echo.
echo ====================================================
echo Islem tamamlandi! GitHub deponuzdaki "Actions" sekmesine
echo giderek APK dosyanizin derlenmesini izleyebilirsiniz.
echo ====================================================
pause
